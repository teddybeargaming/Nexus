For Windows/Win64
- Visual Studio Code (any version, v1.88.0 or later recommended).
- Minimum 1.5 GB space.
- Access to the web just to download the ZIP containing everything you need, lol.
- Executable, download for engine version
   For Mac OS X
  - Same as Windows, except need Azalea to build
    For the web
    Still working on it, lol.
    To download SDK, go to "x.x.x-canary" and select source code
