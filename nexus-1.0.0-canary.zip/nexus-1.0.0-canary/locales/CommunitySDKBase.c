using SystemCollections;
using Nexus3D;
//Code to class this as community SDK, and run mod executable
SDKClass = "community"
  if SDKClass = "community"
nexium.IgnoreFile "GameExec.exe"
  nexium.GameApp "ModLoader.bat"
