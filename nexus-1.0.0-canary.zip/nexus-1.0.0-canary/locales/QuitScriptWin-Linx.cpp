using SystemCollections;
using Nexus3D;
void QuitGame()
{
    Application.Quit
}
