


//"screen_res" variable has current screen resolution
int  = 1080
  //You can change the "screen_res" variable to your preference
  #include locales/graphics/