SystemCollections;
Nexus3D;
#include "metadata-script.cs"
#include "PlayerMovement.c"
camera.position=(player_pos)
