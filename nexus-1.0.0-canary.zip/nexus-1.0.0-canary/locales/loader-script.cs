using SystemCollections;
using Nexus3D;
#include "locales/"
  //Prepares game for execution
  public void LoadGame()
{
  Application.Launch
  }
