OK, this is a simple Nexus 3D demo. In case anyone was wondering what Nexus is, it's basically an open-source game engine I made using C, C# (the essential languages you need to have a knowledge of), HTML (for the web), C++ (for Win/Win64 and Linux games), Swift (for OS X games) & OpenGL. For devs (like me lol) who want to make a game using Nexus, pls visit this website- https://nexus.dev

Licenced under the Apache 2.0 licence, pls read the LICENCE.md file for it
