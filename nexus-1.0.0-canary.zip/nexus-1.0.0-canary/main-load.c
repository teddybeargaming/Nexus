SystemCollections;
Nexus3D;
//Calls game loader to initialize game
void Start(locales/loader-script.cs)
