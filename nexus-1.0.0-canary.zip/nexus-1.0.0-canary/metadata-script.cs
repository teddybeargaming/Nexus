using SystemCollections;
using Nexus3D;
//Loads "locales" folder, which contains game's metadata
#include "locales/"
  //Needs screen refresh, which can only be called in a C# script
  void Update();
